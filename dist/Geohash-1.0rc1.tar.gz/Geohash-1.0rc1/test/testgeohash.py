if __name__ == '__main__':
    import doctest
    print "Testing tests in README.txt..."
    doctest.testfile('../README.txt')
